package hospital.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Employee_info extends JFrame {

    Employee_info(){

        JPanel panel=new JPanel();
        panel.setBounds(5,5,990,590);
        panel.setBackground(new Color(109,164,170));
        panel.setLayout(null);
        add(panel);


        JTable table=new JTable();
        table.setBounds(10,34,980,450);
        table.setBackground(new Color(109,164,170));
        table.setFont(new Font("Tahoma",Font.BOLD,12));
        panel.add(table);

        try{
            conn c= new conn();
            String q= "select*from EMP_INFO";
            ResultSet resultSet=c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        }catch(Exception e){
            e.printStackTrace();
        }

        JLabel lable1=new JLabel("Name");
        lable1.setBounds(41,9,70,20);
        lable1.setFont(new Font("Tahoma",Font.BOLD,14));
        panel.add(lable1);

        JLabel lable2 =new JLabel("Age");
        lable2.setBounds(200,9,70,20);
        lable2.setFont(new Font("Tahoma",Font.BOLD,14));
        panel.add(lable2);


        JLabel lable3 = new JLabel("Phone Number");
        lable3.setBounds(350,9,150,20);
        lable3.setFont(new Font("Tahoma",Font.BOLD,14));
        panel.add(lable3);

        JLabel lable4 = new JLabel("Salary");
        lable4.setBounds(510,9,150,20);
        lable4.setFont(new Font("Tahoma",Font.BOLD,14));
        panel.add(lable4);

        JLabel lable5 = new JLabel("Gmail");
        lable5.setBounds(700,9,150,20);
        lable5.setFont(new Font("Tahoma",Font.BOLD,14));
        panel.add(lable5);

        JLabel lable6 = new JLabel("Aadhar Number");
        lable6.setBounds(840,9,150,20);
        lable6.setFont(new Font("Tahoma",Font.BOLD,14));
        panel.add(lable6);

        JButton button=new JButton("Back");
        button.setBounds(350,500,120,30);
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        panel.add(button);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);

            }
        });


        setUndecorated(true);
        setSize(1000,600);
        setLocation(350,230);
        setLayout(null);
        setVisible(true);

    }

    public static void main(String[]args){
        new Employee_info();
    }
}
